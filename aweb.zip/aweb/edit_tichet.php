<?php require_once("includes/init.php");?>

<?php

//Global connection PDO Object and Attributes

global $conn;

$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//End Global connection


if(empty($_GET['id'])){

    redirect("index.php");
    
} else {

    $the_post_id = $_GET['id'];
    
    $stmt = $conn->query("SELECT * FROM tichete WHERE id='{$_GET['id']}' ");

    $field = $stmt->fetchAll(PDO::FETCH_OBJ);

    // echo '<pre>', var_dump($field[0]->id),'</pre>';
    // die();


}
?>

<?php


//After FORM submit


if(isset($_POST['update'])){


    $tichet = new Tichet();
   
    $tichet->saveValues();

    $tichet->update($the_post_id);
    
    
}

?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h1>

   Tichete deschise


</h1>


<h2><a href="index.php">Inapoi la Index</a></h2>
<!--Formular de incarcare tichete -->
<div>
    <form action="" method="post" enctype="multipart/form-data">

        <label class="" for="denumire">Denumire</label></br>
        <input class="" type="text" name="denumire" value="<?php echo $field[0]->denumire; ?>"></br></br>

        <label class="" for="descriere">Descriere</label></br>
        <textarea type="text" name="descriere" rows="4" cols="50"><?php echo $field[0]->descriere; ?></textarea></br>

        <label class="" for="data">Data</label><?php ?> </br>
        <input class="" type="text" name="data" value="<?php echo $field[0]->date ?>"></br></br>

        <label class="" for="poza">Upload a file</label></br>
        <div>
        <input class="" type="file" name="poza"></br></br>
        <img src="images/<?php echo $field[0]->poza ?>" alt="Imagine">
        <div>

        <label class="" for="parinte">Tichet Parinte</label></br>
        <select class="" name="parinte" id="parinte">
                    
                     
            <?php

            // echo '<pre>',var_dump($row),'</pre>';      
            
            // die();
            
            $stmt_db = $conn->query('SELECT * FROM tichete');
            
            $data_db=$stmt_db->fetchAll(PDO::FETCH_OBJ);
           
            foreach($data_db as $item){

                $item_id = $item->id;
                $item_title = $item->denumire;
             
                echo "<option name='parinte' value='$item_title'>$item_title</option>";

            
            }

                
            ?>


            
        </select>
        </br>
        </br>

       <input type="submit" name="update" class="submit" value="Update tichet">

    </form>


</div>
</br>
</br>



    

<!--Lista tichete deschise -->

<div>
            
            <table>
            <tr>
                <th>ID</th>
                <th>Data</th>                
                <th>Denumire</th>
                <th>Descriere</th>
                <th>Poza</th>
                <th>Parinte</th>
            </tr>

            <?php

            $stmt_list =  $conn->query('SELECT * FROM tichete ORDER BY date DESC');

            $data_list = $stmt_list->fetchAll(PDO::FETCH_OBJ);

            foreach($data_list as $tichet_list){

                echo "<tr>";
                echo "<td>{$tichet_list->id}</td>";
                echo "<td>{$tichet_list->date}</td>";
                echo "<td>{$tichet_list->denumire}</td>";
                echo "<td>{$tichet_list->descriere}</td>";                
                echo "<td>{$tichet_list->poza}</td>";
                echo "<td>{$tichet_list->parinte}</td>";
                echo "<td><a href='edit_tichet.php?id={$tichet_list->id}'>Edit Tichet</a></td>";
                echo "</tr>";
               
            
            }

            ?>
            
            
            </table>

</div>



    
</body>
</html>