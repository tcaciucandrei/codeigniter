<?php require_once("includes/init.php");?>

<?php

//Global connection PDO Object and Attributes

global $conn;

$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//End Global connection


//After FORM submit

 // echo '<pre>',var_dump($row),'</pre>';      
            
// die();


if(isset($_POST['submit'])){
    
    $tichet = new Tichet();
   
    $tichet->saveValues();

    $tichet->insert();
    
    
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h1>

   Tichete deschise


</h1>
<!--Formular de incarcare tichete -->
<div>
    <form action="index.php" method="post" enctype="multipart/form-data">

        <label class="" for="denumire">Denumire</label></br>
        <input class="" type="text" name="denumire" value=""></br></br>

        <label class="" for="descriere">Descriere</label></br>
        <textarea type="text" name="descriere" rows="4" cols="50" placeholder="Prezentati-ne in cateva cuvinte situatia intampinata..."></textarea></br>

        <label class="" for="data">Data</label><?php ?> </br>
        <input class="" type="text" name="data" value="<?php echo date("Y-m-d")?>"></br></br>

        <label class="" for="poza">Upload a file</label></br>
        <input class="" type="file" name="poza" value=""></br></br>

        <label class="" for="parinte">Tichet Parinte</label></br>
        <select class="" name="parinte" id="parinte">
                    
                     
            <?php

            // echo '<pre>',var_dump($row),'</pre>';      
            
            // die();
            
            $stmt = $conn->query('SELECT * FROM tichete');
            
            $data=$stmt->fetchAll(PDO::FETCH_OBJ);
           
            foreach($data as $item){

                $item_id = $item->id;
                $item_title = $item->denumire;
             
                echo "<option name='parinte' value='$item_title'>$item_title</option>";

            
            }

                
            ?>


            
        </select>
        </br>
        </br>

       <input type="submit" name="submit" class="submit" value="Trimite tichet">

    </form>


</div>
</br>
</br>



    

<!--Lista tichete deschise -->

<div>
            
            <table>
            <tr>
                <th>ID</th>
                <th>Data</th>                
                <th>Denumire</th>
                <th>Descriere</th>
                <th>Poza</th>
                <th>Parinte</th>
            </tr>

            <?php

            $stmt_list =  $conn->query('SELECT * FROM tichete ORDER BY date DESC');

            $data_list = $stmt_list->fetchAll(PDO::FETCH_OBJ);

            foreach($data_list as $tichet_list){

                echo "<tr>";
                echo "<td>{$tichet_list->id}</td>";
                echo "<td>{$tichet_list->date}</td>";
                echo "<td>{$tichet_list->denumire}</td>";
                echo "<td>{$tichet_list->descriere}</td>";                
                echo "<td>{$tichet_list->poza}</td>";
                echo "<td>{$tichet_list->parinte}</td>";
                echo "<td><a href='edit_tichet.php?id={$tichet_list->id}'>Edit Tichet</a></td>";
                echo "</tr>";
               
            
            }

            ?>
            
            
            </table>

</div>



    
</body>
</html>