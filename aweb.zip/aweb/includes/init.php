<?php



require_once("config.php");
require_once("database.php");
require_once("tichet.php");

