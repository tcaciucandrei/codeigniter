<?php

//DATABASE CONNECTION CONSTANTS


define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'aweb');
define('DS', '/');




?>  