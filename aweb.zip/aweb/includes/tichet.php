<?php

class Tichet {

    public $id;
    public $denumire;
    public $descriere;
    public $data;
    public $poza;
    public $parinte;

       
    public $tmp_path;
    public $target_path;


    public function insert(){

        global $conn;

        if(move_uploaded_file($this->tmp_path, $this->target_path)){

          //INSERT into DB PDO Query

            $sql = "INSERT INTO tichete (id, denumire, descriere, date, poza, parinte) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt= $conn->prepare($sql);
            $stmt->execute([$this->id, $this->denumire, $this->descriere, $this->data, $this->poza, $this->parinte]);

                
         }
    
    }

    public function update($id){

        global $conn;

        if(!file_exists($this->target_path)){

           move_uploaded_file($this->tmp_path, $this->target_path);

        }

        $sql = "UPDATE tichete SET denumire=?, descriere=?, date=?, poza=?, parinte=? WHERE id=?";
        $stmt= $conn->prepare($sql);
        $stmt->execute([$this->denumire, $this->descriere, $this->data, $this->poza, $this->parinte, $id]);


    }

    //Save $_POST values to Object class atributes

    public function saveValues(){

        $this->target_path = "images/".basename($_FILES['poza']['name']);
        $this->poza = basename($_FILES['poza']['name']);
        $this->tmp_path = $_FILES['poza']['tmp_name'];

        $this->denumire = $_POST['denumire'];
        $this->descriere = $_POST['descriere'];
        $this->data = $_POST['data'];
        $this->parinte = $_POST['parinte'];
               
    }



}
