<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['create/(:any)'] = 'tichete/create/$1';
$route['(:any)'] = 'tichete/create/$1';

$route['edit/(:any)'] = 'tichete/edit/$1';
$route['(:any)'] = 'tichete/edit/$1';



$route['default_controller'] = 'tichete/home';
$route['(:any)'] = 'tichete/home/$1';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
