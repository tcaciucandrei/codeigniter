<h2>Edit</h2>






    </div>

<div>

    <table>
        <tr>
            <th>ID</th>
            <th>Data</th>                
            <th>Denumire</th>
            <th>Descriere</th>
            <th>Poza</th>
            <th>Parinte</th>
        </tr>

    <?php if(isset($tichete)) : ?>
        <?php foreach($tichete as $tichet) : ?>

        <tr>
            <td><?php echo $tichet['id']; ?></td>
            <td><?php echo $tichet['date']; ?></td>
            <td><?php echo $tichet['denumire']; ?></td>
            <td><?php echo $tichet['descriere']; ?></td>
            <td><?php echo $tichet['poza']; ?></td>
            <td><?php echo $tichet['parinte']; ?></td>
            <td><a href="edit/<?php echo $tichet['id']; ?>">Edit tichet</a></td>
        </tr>

        <?php endforeach; ?>

        <?php else: ?>

            <tr>
            <td><?php echo $tichet['id']; ?></td>
            <td><?php echo $tichet['date']; ?></td>
            <td><?php echo $tichet['denumire']; ?></td>
            <td><?php echo $tichet['descriere']; ?></td>
            <td><?php echo $tichet['poza']; ?></td>
            <td><?php echo $tichet['parinte']; ?></td>
            <td><a href="edit/<?php echo $tichet['id']; ?>">Edit tichet</a></td>
        </tr>
        
        

        <?php endif; ?>

    </table>

</div>

        </br>
        </br>
        

<div>

    <form class="form-group" action="" method="post" enctype="multipart/form-data">

            <label  for="denumire">Denumire</label></br>
            <input class="form-control" type="text" name="denumire" value="<?= $tichet['denumire']; ?>"></br></br>

            <label  for="descriere">Descriere</label></br>
            <textarea class="form-control" type="text" name="descriere" rows="4" cols="50" placeholder="Prezentati-ne in cateva cuvinte situatia intampinata..."><?= $tichet['descriere'];?></textarea></br>

            <label  for="data">Data</label><?php ?> </br>
            <input class="form-control" type="text" name="data" value="<?= $tichet['date'];?>"></br></br>

            <label for="poza">Upload a file</label></br>
            <input class="form-control" type="file" name="poza" value=""></br></br>

            <label class="" for="parinte">Tichet Parinte</label></br>
            <select class="form-control" name="parinte" id="parinte">

                <option name='parinte' value="<?= $tichet['parinte'];?>"><?= $tichet['parinte'];?></option>";
                    
            </select>
            </br>
            </br>

        <input type="submit" name="update" class="update" value="Update tichet">

        </form>