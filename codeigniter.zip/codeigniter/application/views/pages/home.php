<h2><?= $title ?></h2>

<div>

    <?php echo form_open(''); ?>

            <label  for="denumire">Denumire</label></br>
            <input class="form-control" type="text" name="denumire" value=""></br></br>

            <label  for="descriere">Descriere</label></br>
            <textarea class="form-control" type="text" name="descriere" rows="4" cols="50" placeholder="Prezentati-ne in cateva cuvinte situatia intampinata..."></textarea></br>

            <label  for="data">Data</label><?php ?> </br>
            <input class="form-control" type="text" name="data" value="<?php echo date("Y-m-d")?>"></br></br>

            <label for="poza">Upload a file</label></br>
            <input class="form-control" type="file" name="poza" value=""></br></br>

            <label class="" for="parinte">Tichet Parinte</label></br>
            <select class="form-control" name="parinte" id="parinte">

                <?php foreach($tichete as $tichet) : ?>

                    <option name='parinte' value="<?= $tichet['denumire'];?>"><?= $tichet['denumire'];?></option>";

                <?php endforeach; ?>
                        
            
            </select>
            </br>
            </br>

        <input type="submit" name="submit" class="submit" value="Trimite tichet">

        </form>



    </div>

<div>

    <table>
                <tr>
                    <th>ID</th>
                    <th>Data</th>                
                    <th>Denumire</th>
                    <th>Descriere</th>
                    <th>Poza</th>
                    <th>Parinte</th>
                </tr>

    <?php foreach($tichete as $tichet) : ?>
        <tr>
        <td><?php echo $tichet['id']; ?></td>
        <td><?php echo $tichet['date']; ?></td>
        <td><?php echo $tichet['denumire']; ?></td>
        <td><?php echo $tichet['descriere']; ?></td>
        <td><?php echo $tichet['poza']; ?></td>
        <td><?php echo $tichet['parinte']; ?></td>
        <td><a href="edit/<?php echo $tichet['id']; ?>">Edit tichet</a></td>
    </tr>



    <?php endforeach; ?>

    </table>

</div>