<html>

    <head>
    
        <title>Tichete Deschise</title>
        <link rel="stylesheet" href="https://bootswatch.com/4/litera/bootstrap.css">

    </head>

    <body>
        <nav class="navbar navbar-inverse">
            <div class="container">

                <div class="navbar-header">
                    <a href="/codeigniter/" class="navbar-header">Codeigniter</a>        
                
                </div>
                <div id="navbar">

                    <ul class="nav navbar-nav">

                        <li><a href="/codeigniter/">Tichete</a></li>
                        <li><a href="/codeigniter/edit">Edit Tichete</a></li>
                    
                    
                    </ul>
                
                </div>
            
            </div>
        
        </nav>
        <div class="container">
        
        
        

    
