<?php

class Tichete extends CI_Controller{

    public function home($page = 'home'){

        if(!file_exists(APPPATH.'views/pages/'.$page.'.php')){
            
            show_404();
        }

        $data['title'] = ucfirst($page);

        $data['tichete'] = $this->tichet_model->get_tichete();

        //print_r($data['tichete']);

        

        $this->load->view('templates/header');
        $this->load->view('pages/'.$page, $data);
        $this->load->view('templates/footer');

    }

    public function edit($id = NULL){

        $data['tichet'] = $this->tichet_model->get_tichete($id);

        // print_r($data['tichet']);

        // die();

        if(empty($data['tichet'])){

            show_404();
        }

        $data['title'] = $data['tichet']['denumire'];

        $this->load->view('templates/header');
        $this->load->view('pages/edit', $data);
        $this->load->view('templates/footer');

    }

    public function create(){

        $data['title'] = 'Create';

        $this->load->view('templates/header');
        $this->load->view('pages/create', $data);
        $this->load->view('templates/footer');

    }

}


